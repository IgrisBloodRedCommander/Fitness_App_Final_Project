/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package final_project;

import com.formdev.flatlaf.intellijthemes.FlatGradiantoNatureGreenIJTheme;


/**
 *
 * @author User
 */
public class Final_Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try {
           
            FlatGradiantoNatureGreenIJTheme.setup();
        } catch (Exception ex) {
            System.err.println("Failed to initialize theme. Using default.");
        }
        java.awt.EventQueue.invokeLater(() -> {
            LoginGUI showApp = new LoginGUI();
            showApp.show();
        });
    }
    
    }
    
